# [Credit_Card_Fraud_Detection](https://creditcard-fraud-transaction.herokuapp.com/)
This repository basically deals with a machine learning project based on clustering  and various other algorithms. It basically tells whether a fraudulent transaction has occured or not.

![Web capture_12-10-2022_134757_creditcard-fraud-transaction herokuapp com](https://user-images.githubusercontent.com/69504019/195289563-ea4eff90-3c9a-418b-9db1-bf3a5f2edeb7.jpeg)
